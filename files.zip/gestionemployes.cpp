#include "gestionemployes.h"
#include "ui_gestionemployes.h"

#include "connection.h"

#include <QDateTime>
#include <QDesktopServices>
#include <QDialog>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QHeaderView>
#include <QImage>
#include <QItemSelectionModel>
#include <QLabel>
#include <QMessageBox>
#include <QPixmap>
#include <QPushButton>
#include <QRegularExpression>
#include <QRegularExpressionValidator>
#include <QResizeEvent>
#include <QSqlError>
#include <QSqlQueryModel>
#include <QTableView>
#include <QUrl>
#include <QVBoxLayout>

/* =====================================================================
 *  Construction / destruction
 * ===================================================================== */

GestionEmployes::GestionEmployes(QWidget *parent)
    : QWidget(parent),
      ui(new Ui::GestionEmployes),
      m_modele(nullptr),
      m_idSelectionne(0)
{
    ui->setupUi(this);

    appliquerCharteGraphique();
    configurerChamps();

    /* CRUD */
    connect(ui->pushButtonAjouter, &QPushButton::clicked, this, &GestionEmployes::slotAjouter);
    connect(ui->pushButtonModifier, &QPushButton::clicked, this, &GestionEmployes::slotModifier);
    connect(ui->pushButtonSupprimer, &QPushButton::clicked, this, &GestionEmployes::slotSupprimer);
    connect(ui->pushButtonAnnuler, &QPushButton::clicked, this, &GestionEmployes::slotAnnuler);

    /* Recherche instantanée */
    connect(ui->lineEditRecherche, &QLineEdit::textChanged, this, &GestionEmployes::slotRechercher);

    /* Tri et filtres (currentIndexChanged) */
    connect(ui->comboTri, SIGNAL(currentIndexChanged(int)), this, SLOT(slotTrier()));
    connect(ui->comboOrdre, SIGNAL(currentIndexChanged(int)), this, SLOT(slotTrier()));
    connect(ui->comboFiltreService, SIGNAL(currentIndexChanged(int)), this, SLOT(slotTrier()));
    connect(ui->comboFiltreStatut, SIGNAL(currentIndexChanged(int)), this, SLOT(slotTrier()));

    /* Exportation PDF */
    connect(ui->pushButtonExporterPDF, &QPushButton::clicked, this, &GestionEmployes::slotExporterPDF);
    connect(ui->pushButtonFichePDF, &QPushButton::clicked, this, &GestionEmployes::slotExporterFichePDF);

    /* Statistiques */
    connect(ui->pushButtonStatistiques, &QPushButton::clicked, this,
            &GestionEmployes::slotAfficherStatistiques);
    connect(ui->pushButtonActualiserStats, &QPushButton::clicked, this,
            &GestionEmployes::slotActualiserStatistiques);
    connect(ui->comboStatsCritere, SIGNAL(currentIndexChanged(int)), this,
            SLOT(slotActualiserStatistiques()));
    connect(ui->tabWidget, &QTabWidget::currentChanged, this, &GestionEmployes::slotChangementOnglet);

    /* Métiers innovants */
    connect(ui->pushButtonParcourir, &QPushButton::clicked, this, &GestionEmployes::slotParcourirPhoto);
    connect(ui->pushButtonHistorique, &QPushButton::clicked, this,
            &GestionEmployes::slotAfficherHistorique);

    actualiserListe();

    Employe::journaliser("CONNEXION", "Ouverture du module Gestion des employés", 0);
}

GestionEmployes::~GestionEmployes()
{
    delete m_modele;
    delete ui;
}

/* =====================================================================
 *  Apparence (charte graphique SWM)
 * ===================================================================== */

void GestionEmployes::appliquerCharteGraphique()
{
    setStyleSheet(QString(R"(
        QWidget#GestionEmployes { background-color: #E8EEF2; }
        QLabel { color: #24384B; }
        QLabel#labelTitre {
            background-color: #24384B; color: #E6A15C;
            font-size: 22px; font-weight: bold; letter-spacing: 1px;
        }
        QLabel#labelPhoto {
            background-color: #FFFFFF; border: 2px solid #24384B; border-radius: 6px;
            color: #24384B;
        }
        QTabWidget::pane { border: 1px solid #24384B; background-color: #E8EEF2; }
        QTabBar::tab {
            background-color: #24384B; color: #FFFFFF; padding: 9px 22px;
            margin-right: 2px; font-weight: bold;
        }
        QTabBar::tab:selected { background-color: #208A9A; }
        QLineEdit, QComboBox, QTextEdit {
            background-color: #FFFFFF; color: #24384B;
            border: 1px solid #24384B; border-radius: 4px; padding: 5px;
        }
        QLineEdit:focus, QComboBox:focus { border: 2px solid #208A9A; }
        QLineEdit:read-only { background-color: #E8EEF2; }
        QComboBox QAbstractItemView {
            background-color: #FFFFFF; color: #24384B;
            selection-background-color: #208A9A; selection-color: #FFFFFF;
        }
        QTableView {
            background-color: #FFFFFF; alternate-background-color: #E8EEF2;
            gridline-color: #C9D4DC; border: 1px solid #24384B;
            selection-background-color: #208A9A; selection-color: #FFFFFF;
        }
        QHeaderView::section {
            background-color: #24384B; color: #FFFFFF; padding: 6px;
            border: none; font-weight: bold;
        }
        QPushButton {
            background-color: #208A9A; color: #FFFFFF; border: none;
            border-radius: 5px; padding: 9px 16px; font-weight: bold;
        }
        QPushButton:hover { background-color: #1A7280; }
        QPushButton:pressed { background-color: #145862; }
        QPushButton:disabled { background-color: #9DB5BC; }
        QPushButton#pushButtonSupprimer, QPushButton#pushButtonAnnuler {
            background-color: #24384B;
        }
        QPushButton#pushButtonSupprimer:hover, QPushButton#pushButtonAnnuler:hover {
            background-color: #31506B;
        }
        QGroupBox {
            background-color: #FFFFFF; border: 1px solid #24384B; border-radius: 6px;
            margin-top: 14px; color: #24384B; font-weight: bold;
        }
        QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 6px; }
        QGraphicsView { background-color: #FFFFFF; border: 1px solid #24384B; }
    )"));
}

void GestionEmployes::configurerChamps()
{
    /* ---- Fiche ---- */
    ui->lineEditId->setReadOnly(true);
    ui->lineEditId->setText("(auto)");

    ui->lineEditNom->setMaxLength(50);
    ui->lineEditPrenom->setMaxLength(50);
    ui->lineEditEmail->setMaxLength(100);
    ui->lineEditTelephone->setMaxLength(8);
    ui->lineEditSalaire->setMaxLength(10);

    ui->lineEditNom->setPlaceholderText("Ex : Maamouri");
    ui->lineEditPrenom->setPlaceholderText("Ex : Yassmine");
    ui->lineEditEmail->setPlaceholderText("prenom.nom@exemple.tn");
    ui->lineEditTelephone->setPlaceholderText("8 chiffres");
    ui->lineEditSalaire->setPlaceholderText("Ex : 1850.50");

    /* Saisie bloquée en direct : lettres pour les noms, chiffres pour le téléphone. */
    ui->lineEditNom->setValidator(
        new QRegularExpressionValidator(QRegularExpression("[\\p{L} '\\-]{0,50}"), this));
    ui->lineEditPrenom->setValidator(
        new QRegularExpressionValidator(QRegularExpression("[\\p{L} '\\-]{0,50}"), this));
    ui->lineEditTelephone->setValidator(
        new QRegularExpressionValidator(QRegularExpression("[0-9]{0,8}"), this));
    ui->lineEditSalaire->setValidator(
        new QRegularExpressionValidator(QRegularExpression("[0-9]{0,7}([\\.,][0-9]{0,2})?"), this));

    const QStringList postes = QStringList()
                               << "Administrateur" << "Responsable RH" << "Responsable"
                               << "Technicien" << "Météorologue" << "Ingénieur"
                               << "Agent d'observation";
    const QStringList services = QStringList()
                                 << "Direction" << "Ressources humaines"
                                 << "Observation et réseau de stations" << "Prévision"
                                 << "Maintenance et instruments" << "Informatique et données"
                                 << "Climatologie";

    ui->comboPoste->addItems(postes);
    ui->comboService->addItems(services);
    ui->comboStatut->addItems(Employe::statutsValides());

    /* ---- Tri et filtres ---- */
    ui->comboTri->addItems(QStringList() << "ID" << "Nom" << "Prénom" << "Salaire" << "Service"
                                         << "Poste" << "Statut");
    ui->comboOrdre->addItems(QStringList() << "Croissant" << "Décroissant");

    ui->comboFiltreService->addItem("Tous les services");
    ui->comboFiltreService->addItems(services);
    ui->comboFiltreStatut->addItem("Tous les statuts");
    ui->comboFiltreStatut->addItems(Employe::statutsValides());

    /* ---- Statistiques ---- */
    ui->comboStatsCritere->addItems(QStringList() << "Service" << "Poste" << "Statut");

    /* ---- Tableau ---- */
    ui->tableViewEmployes->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableViewEmployes->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableViewEmployes->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableViewEmployes->setAlternatingRowColors(true);
    ui->tableViewEmployes->verticalHeader()->hide();

    /* ---- Photo ---- */
    ui->labelPhoto->setFixedSize(130, 130);
    ui->labelPhoto->setText("Aucune photo");
}

/* =====================================================================
 *  Liste et modèle
 * ===================================================================== */

void GestionEmployes::definirModele(QSqlQueryModel *nouveau)
{
    while (nouveau->canFetchMore()) {
        nouveau->fetchMore();
    }

    ui->tableViewEmployes->setModel(nouveau);

    QSqlQueryModel *ancien = m_modele;
    m_modele = nouveau;
    delete ancien;

    QHeaderView *entete = ui->tableViewEmployes->horizontalHeader();
    entete->setSectionResizeMode(QHeaderView::ResizeToContents);
    entete->setStretchLastSection(true);

    connect(ui->tableViewEmployes->selectionModel(), &QItemSelectionModel::currentRowChanged, this,
            &GestionEmployes::slotLigneChangee);
}

void GestionEmployes::actualiserListe()
{
    const QString critere = ui->comboTri->currentText();
    const QString ordre = ui->comboOrdre->currentText();
    const QString service = ui->comboFiltreService->currentText();
    const QString statut = ui->comboFiltreStatut->currentText();
    const QString recherche = ui->lineEditRecherche->text().trimmed();

    Employe e;
    QSqlQueryModel *nouveau = recherche.isEmpty()
                                  ? e.trier(critere, ordre, service, statut)
                                  : e.rechercher(recherche, critere, ordre, service, statut);

    if (nouveau->lastError().isValid()) {
        QMessageBox::critical(this, "Erreur base de données", nouveau->lastError().text());
    }

    definirModele(nouveau);
    ui->labelCompteur->setText(QString::number(nouveau->rowCount()) + " employé(s) affiché(s)");
}

void GestionEmployes::slotRechercher(const QString &texte)
{
    Q_UNUSED(texte);
    actualiserListe();
}

void GestionEmployes::slotTrier()
{
    actualiserListe();
}

void GestionEmployes::slotLigneChangee(const QModelIndex &courant, const QModelIndex &precedent)
{
    Q_UNUSED(precedent);
    if (!courant.isValid() || !m_modele) {
        return;
    }

    const int id = m_modele->data(m_modele->index(courant.row(), 0)).toInt();
    bool ok = false;
    const Employe e = Employe::charger(id, &ok);
    if (!ok) {
        return;
    }

    m_idSelectionne = id;
    remplirFiche(e);
}

/* =====================================================================
 *  Fiche : remplissage, vidage, photo
 * ===================================================================== */

void GestionEmployes::remplirFiche(const Employe &employe)
{
    ui->lineEditId->setText(QString::number(employe.getId()));
    ui->lineEditNom->setText(employe.getNom());
    ui->lineEditPrenom->setText(employe.getPrenom());
    ui->lineEditEmail->setText(employe.getEmail());
    ui->lineEditTelephone->setText(employe.getTelephone());
    ui->lineEditSalaire->setText(QString::number(employe.getSalaire(), 'f', 2));

    int indexPoste = ui->comboPoste->findText(employe.getPoste());
    if (indexPoste < 0) {
        ui->comboPoste->addItem(employe.getPoste());
        indexPoste = ui->comboPoste->count() - 1;
    }
    ui->comboPoste->setCurrentIndex(indexPoste);

    int indexService = ui->comboService->findText(employe.getService());
    if (indexService < 0) {
        ui->comboService->addItem(employe.getService());
        indexService = ui->comboService->count() - 1;
    }
    ui->comboService->setCurrentIndex(indexService);

    const int indexStatut = ui->comboStatut->findText(employe.getStatut());
    ui->comboStatut->setCurrentIndex(indexStatut >= 0 ? indexStatut : 0);

    m_cheminPhoto = employe.getPhoto();
    m_photoSource.clear();
    afficherPhoto(m_cheminPhoto);
}

void GestionEmployes::viderFiche()
{
    m_idSelectionne = 0;
    m_cheminPhoto.clear();
    m_photoSource.clear();

    ui->lineEditId->setText("(auto)");
    ui->lineEditNom->clear();
    ui->lineEditPrenom->clear();
    ui->lineEditEmail->clear();
    ui->lineEditTelephone->clear();
    ui->lineEditSalaire->clear();
    ui->comboPoste->setCurrentIndex(0);
    ui->comboService->setCurrentIndex(0);
    ui->comboStatut->setCurrentIndex(0);
    afficherPhoto(QString());

    ui->tableViewEmployes->clearSelection();
    ui->lineEditNom->setFocus();
}

void GestionEmployes::afficherPhoto(const QString &chemin)
{
    if (!chemin.isEmpty() && QFileInfo::exists(chemin)) {
        const QPixmap pixmap(chemin);
        if (!pixmap.isNull()) {
            ui->labelPhoto->setPixmap(pixmap.scaled(ui->labelPhoto->size() - QSize(6, 6),
                                                    Qt::KeepAspectRatio, Qt::SmoothTransformation));
            return;
        }
    }
    ui->labelPhoto->setPixmap(QPixmap());
    ui->labelPhoto->setText("Aucune photo");
}

QString GestionEmployes::dossierPhotos()
{
    return Connection::dossierDonnees() + "/photos";
}

/* Convertit l'image choisie en PNG (400 x 400 maximum) et la copie dans le dossier photos. */
QString GestionEmployes::enregistrerPhoto(const QString &source)
{
    QImage image(source);
    if (image.isNull()) {
        return QString();
    }
    if (image.width() > 400 || image.height() > 400) {
        image = image.scaled(400, 400, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    }

    QDir().mkpath(dossierPhotos());
    const QString destination = dossierPhotos() + "/employe_"
                                + QString::number(QDateTime::currentMSecsSinceEpoch()) + ".png";
    if (!image.save(destination, "PNG")) {
        return QString();
    }
    return destination;
}

void GestionEmployes::slotParcourirPhoto()
{
    const QString fichier = QFileDialog::getOpenFileName(
        this, "Choisir une photo de profil", QDir::homePath(),
        "Images (*.png *.jpg *.jpeg *.PNG *.JPG *.JPEG)");
    if (fichier.isEmpty()) {
        return;
    }

    const QPixmap pixmap(fichier);
    if (pixmap.isNull()) {
        QMessageBox::warning(this, "Photo invalide",
                             "Le fichier sélectionné n'est pas une image valide (JPG ou PNG).");
        return;
    }

    m_photoSource = fichier;
    ui->labelPhoto->setPixmap(pixmap.scaled(ui->labelPhoto->size() - QSize(6, 6),
                                            Qt::KeepAspectRatio, Qt::SmoothTransformation));
}

/* =====================================================================
 *  Contrôle de saisie
 * ===================================================================== */

void GestionEmployes::avertir(const QString &message, QWidget *champ)
{
    QMessageBox::warning(this, "Contrôle de saisie", message);
    if (champ) {
        champ->setFocus();
    }
}

bool GestionEmployes::lireEtValiderFiche(Employe &employe, bool &nouvellePhoto)
{
    nouvellePhoto = false;

    const QString nom = ui->lineEditNom->text().trimmed();
    const QString prenom = ui->lineEditPrenom->text().trimmed();
    const QString email = ui->lineEditEmail->text().trimmed();
    const QString telephone = ui->lineEditTelephone->text().trimmed();
    const QString poste = ui->comboPoste->currentText().trimmed();
    const QString service = ui->comboService->currentText().trimmed();
    const QString statut = ui->comboStatut->currentText().trimmed();
    QString texteSalaire = ui->lineEditSalaire->text().trimmed();
    texteSalaire.replace(',', '.');

    if (nom.isEmpty()) {
        avertir("Le nom est obligatoire.", ui->lineEditNom);
        return false;
    }
    if (!Employe::nomValide(nom)) {
        avertir("Le nom est invalide : 2 à 50 caractères, uniquement des lettres, espaces, "
                "apostrophes ou tirets.",
                ui->lineEditNom);
        return false;
    }

    if (prenom.isEmpty()) {
        avertir("Le prénom est obligatoire.", ui->lineEditPrenom);
        return false;
    }
    if (!Employe::nomValide(prenom)) {
        avertir("Le prénom est invalide : 2 à 50 caractères, uniquement des lettres, espaces, "
                "apostrophes ou tirets.",
                ui->lineEditPrenom);
        return false;
    }

    if (email.isEmpty()) {
        avertir("L'adresse e-mail est obligatoire.", ui->lineEditEmail);
        return false;
    }
    if (!Employe::emailValide(email)) {
        avertir("L'adresse e-mail est invalide. Format attendu : nom@domaine.tn", ui->lineEditEmail);
        return false;
    }

    if (telephone.isEmpty()) {
        avertir("Le numéro de téléphone est obligatoire.", ui->lineEditTelephone);
        return false;
    }
    if (!Employe::telephoneValide(telephone)) {
        avertir("Le téléphone doit contenir exactement 8 chiffres.", ui->lineEditTelephone);
        return false;
    }

    if (poste.isEmpty()) {
        avertir("Le poste est obligatoire.", ui->comboPoste);
        return false;
    }
    if (service.isEmpty()) {
        avertir("Le service est obligatoire.", ui->comboService);
        return false;
    }

    if (texteSalaire.isEmpty()) {
        avertir("Le salaire est obligatoire.", ui->lineEditSalaire);
        return false;
    }
    bool salaireOk = false;
    const double salaire = texteSalaire.toDouble(&salaireOk);
    if (!salaireOk || !Employe::salaireValide(salaire)) {
        avertir("Le salaire doit être un nombre strictement positif (maximum 1 000 000 DT).",
                ui->lineEditSalaire);
        return false;
    }

    if (!Employe::statutsValides().contains(statut)) {
        avertir("Le statut doit être Actif, En congé ou Inactif.", ui->comboStatut);
        return false;
    }

    /* Photo : conversion et copie de la nouvelle image choisie, sinon conservation de l'ancienne. */
    QString photo = m_cheminPhoto;
    if (!m_photoSource.isEmpty()) {
        photo = enregistrerPhoto(m_photoSource);
        if (photo.isEmpty()) {
            QMessageBox::warning(this, "Photo de profil",
                                 "Impossible d'enregistrer la photo sélectionnée.");
            return false;
        }
        nouvellePhoto = true;
    }

    employe = Employe(m_idSelectionne, nom, prenom, email, telephone, poste, service, salaire,
                      statut, photo);
    return true;
}

/* =====================================================================
 *  CRUD
 * ===================================================================== */

void GestionEmployes::slotAjouter()
{
    Employe e;
    bool nouvellePhoto = false;
    if (!lireEtValiderFiche(e, nouvellePhoto)) {
        return;
    }

    if (e.ajouter()) {
        QMessageBox::information(this, "Ajout d'un employé",
                                 "L'employé " + e.getPrenom() + " " + e.getNom()
                                     + " a été ajouté avec succès (ID " + QString::number(e.getId())
                                     + ").");
        viderFiche();
        actualiserListe();
    } else {
        if (nouvellePhoto) {
            QFile::remove(e.getPhoto());
        }
        QMessageBox::critical(this, "Ajout impossible", e.derniereErreur());
    }
}

void GestionEmployes::slotModifier()
{
    if (m_idSelectionne <= 0) {
        QMessageBox::information(this, "Modification",
                                 "Veuillez d'abord sélectionner un employé dans le tableau.");
        return;
    }

    Employe e;
    bool nouvellePhoto = false;
    if (!lireEtValiderFiche(e, nouvellePhoto)) {
        return;
    }

    if (e.modifier(m_idSelectionne)) {
        QMessageBox::information(this, "Modification", "Les informations ont été mises à jour.");
        m_cheminPhoto = e.getPhoto();
        m_photoSource.clear();
        actualiserListe();
    } else {
        if (nouvellePhoto) {
            QFile::remove(e.getPhoto());
        }
        QMessageBox::critical(this, "Modification impossible", e.derniereErreur());
    }
}

void GestionEmployes::slotSupprimer()
{
    if (m_idSelectionne <= 0) {
        QMessageBox::information(this, "Suppression",
                                 "Veuillez d'abord sélectionner un employé dans le tableau.");
        return;
    }

    const QString identite = ui->lineEditPrenom->text().trimmed() + " "
                             + ui->lineEditNom->text().trimmed();
    const QMessageBox::StandardButton reponse = QMessageBox::question(
        this, "Confirmation",
        "Voulez-vous vraiment désactiver l'employé " + identite
            + " ?\nSon statut passera à « Inactif » et son historique sera conservé.",
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No);
    if (reponse != QMessageBox::Yes) {
        return;
    }

    Employe e;
    if (e.supprimer(m_idSelectionne)) {
        QMessageBox::information(this, "Suppression",
                                 "L'employé a été désactivé (statut : Inactif).");
        const int id = m_idSelectionne;
        actualiserListe();

        bool ok = false;
        const Employe maj = Employe::charger(id, &ok);
        if (ok) {
            m_idSelectionne = id;
            remplirFiche(maj);
        }
    } else {
        QMessageBox::warning(this, "Suppression impossible", e.derniereErreur());
    }
}

void GestionEmployes::slotAnnuler()
{
    viderFiche();

    /* Réinitialisation de la recherche, du tri et des filtres sans multiplier les rafraîchissements. */
    const QList<QWidget *> controles = {ui->lineEditRecherche, ui->comboTri, ui->comboOrdre,
                                        ui->comboFiltreService, ui->comboFiltreStatut};
    for (QWidget *w : controles) {
        w->blockSignals(true);
    }
    ui->lineEditRecherche->clear();
    ui->comboTri->setCurrentIndex(0);
    ui->comboOrdre->setCurrentIndex(0);
    ui->comboFiltreService->setCurrentIndex(0);
    ui->comboFiltreStatut->setCurrentIndex(0);
    for (QWidget *w : controles) {
        w->blockSignals(false);
    }

    actualiserListe();
}

/* =====================================================================
 *  Exportation PDF
 * ===================================================================== */

void GestionEmployes::slotExporterPDF()
{
    QString fichier = QFileDialog::getSaveFileName(
        this, "Exporter la liste des employés en PDF",
        QDir::homePath() + "/liste_employes.pdf", "Documents PDF (*.pdf)");
    if (fichier.isEmpty()) {
        return;
    }
    if (!fichier.endsWith(".pdf", Qt::CaseInsensitive)) {
        fichier += ".pdf";
    }

    QStringList criteres;
    if (ui->comboFiltreService->currentIndex() > 0) {
        criteres << "Service : " + ui->comboFiltreService->currentText();
    }
    if (ui->comboFiltreStatut->currentIndex() > 0) {
        criteres << "Statut : " + ui->comboFiltreStatut->currentText();
    }
    if (!ui->lineEditRecherche->text().trimmed().isEmpty()) {
        criteres << "Recherche : « " + ui->lineEditRecherche->text().trimmed() + " »";
    }
    criteres << "Tri : " + ui->comboTri->currentText() + " (" + ui->comboOrdre->currentText() + ")";

    Employe e;
    if (e.exporterPDF(fichier, m_modele, criteres.join(" - "))) {
        QMessageBox::information(this, "Exportation PDF",
                                 "La liste a été exportée avec succès :\n" + fichier);
        QDesktopServices::openUrl(QUrl::fromLocalFile(fichier));
    } else {
        QMessageBox::critical(this, "Exportation PDF", e.derniereErreur());
    }
}

void GestionEmployes::slotExporterFichePDF()
{
    if (m_idSelectionne <= 0) {
        QMessageBox::information(this, "Fiche PDF",
                                 "Veuillez d'abord sélectionner un employé dans le tableau.");
        return;
    }

    QString fichier = QFileDialog::getSaveFileName(
        this, "Exporter la fiche de l'employé en PDF",
        QDir::homePath() + "/fiche_employe_" + QString::number(m_idSelectionne) + ".pdf",
        "Documents PDF (*.pdf)");
    if (fichier.isEmpty()) {
        return;
    }
    if (!fichier.endsWith(".pdf", Qt::CaseInsensitive)) {
        fichier += ".pdf";
    }

    Employe e;
    if (e.exporterFichePDF(fichier, m_idSelectionne)) {
        QMessageBox::information(this, "Fiche PDF",
                                 "La fiche a été exportée avec succès :\n" + fichier);
        QDesktopServices::openUrl(QUrl::fromLocalFile(fichier));
    } else {
        QMessageBox::critical(this, "Fiche PDF", e.derniereErreur());
    }
}

/* =====================================================================
 *  Statistiques
 * ===================================================================== */

void GestionEmployes::slotAfficherStatistiques()
{
    ui->tabWidget->setCurrentIndex(1);
    slotActualiserStatistiques();
}

void GestionEmployes::slotChangementOnglet(int index)
{
    if (index == 1) {
        slotActualiserStatistiques();
    }
}

void GestionEmployes::slotActualiserStatistiques()
{
    const QString critere = ui->comboStatsCritere->currentText();

    Employe e;
    const int total = e.statistique(ui->graphicsViewStats, critere);
    ui->labelTotalStats->setText("Total : " + QString::number(total)
                                 + " employé(s) - répartition par " + critere.toLower());
}

void GestionEmployes::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    if (ui->graphicsViewStats->scene()) {
        ui->graphicsViewStats->fitInView(ui->graphicsViewStats->scene()->sceneRect(),
                                         Qt::KeepAspectRatio);
    }
}

/* =====================================================================
 *  Historique d'activité (fenêtre dédiée)
 * ===================================================================== */

void GestionEmployes::slotAfficherHistorique()
{
    QDialog fenetre(this);
    fenetre.setWindowTitle("Historique d'activité");
    fenetre.resize(860, 480);
    fenetre.setStyleSheet("QDialog { background-color: #E8EEF2; }");

    QVBoxLayout *disposition = new QVBoxLayout(&fenetre);

    QString titre = "Historique d'activité - tous les employés";
    if (m_idSelectionne > 0) {
        titre = "Historique d'activité - " + ui->lineEditPrenom->text().trimmed() + " "
                + ui->lineEditNom->text().trimmed() + " (ID " + QString::number(m_idSelectionne)
                + ")";
    }
    QLabel *etiquette = new QLabel(titre, &fenetre);
    etiquette->setStyleSheet("font-size: 15px; font-weight: bold; color: #24384B;");
    disposition->addWidget(etiquette);

    QTableView *tableau = new QTableView(&fenetre);
    QSqlQueryModel *modele = Employe::historique(m_idSelectionne);
    modele->setParent(&fenetre);
    while (modele->canFetchMore()) {
        modele->fetchMore();
    }
    tableau->setModel(modele);
    tableau->setEditTriggers(QAbstractItemView::NoEditTriggers);
    tableau->setSelectionBehavior(QAbstractItemView::SelectRows);
    tableau->setAlternatingRowColors(true);
    tableau->verticalHeader()->hide();
    tableau->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    tableau->horizontalHeader()->setStretchLastSection(true);
    disposition->addWidget(tableau);

    QLabel *compteur = new QLabel(QString::number(modele->rowCount()) + " événement(s) enregistré(s)",
                                  &fenetre);
    compteur->setStyleSheet("color: #24384B;");
    disposition->addWidget(compteur);

    QPushButton *fermer = new QPushButton("Fermer", &fenetre);
    connect(fermer, &QPushButton::clicked, &fenetre, &QDialog::accept);
    disposition->addWidget(fermer, 0, Qt::AlignRight);

    fenetre.exec();
}
