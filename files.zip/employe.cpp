#include "employe.h"

#include <QBrush>
#include <QColor>
#include <QDateTime>
#include <QFile>
#include <QFileInfo>
#include <QFont>
#include <QGraphicsScene>
#include <QGraphicsTextItem>
#include <QGraphicsView>
#include <QImage>
#include <QMarginsF>
#include <QPageLayout>
#include <QPageSize>
#include <QPainter>
#include <QPair>
#include <QPdfWriter>
#include <QPen>
#include <QRegularExpression>
#include <QSqlError>
#include <QSqlQuery>
#include <QTextDocument>
#include <QTextOption>
#include <QUrl>
#include <QVariant>
#include <QVector>
#include <cmath>
#include <memory>
#include <utility>

namespace {

const QString COULEUR_MARINE = "#24384B";
const QString COULEUR_TURQUOISE = "#208A9A";
const QString COULEUR_GRIS = "#E8EEF2";
const QString COULEUR_DORE = "#E6A15C";

QString formaterSalaire(double salaire)
{
    return QString::number(salaire, 'f', 2) + " DT";
}

/* Écrit un QTextDocument dans un fichier PDF A4 avec des marges de 12 mm. */
bool ecrirePdf(const QString &fichier, QTextDocument &document)
{
    {
        QPdfWriter writer(fichier);
#if QT_VERSION >= QT_VERSION_CHECK(5, 15, 0)
        writer.setPageSize(QPageSize(QPageSize::A4));
        writer.setPageMargins(QMarginsF(12, 12, 12, 12), QPageLayout::Millimeter);
#else
        writer.setPageSize(QPagedPaintDevice::A4);
        writer.setPageMargins(QMarginsF(12, 12, 12, 12));
#endif
        document.print(&writer);
    }
    const QFileInfo info(fichier);
    return info.exists() && info.size() > 0;
}

/* Bandeau d'en-tête commun aux rapports PDF. */
QString bandeauHtml(const QString &sousTitre)
{
    QString html;
    html += "<table width=\"100%\" cellpadding=\"10\" cellspacing=\"0\"><tr>";
    html += "<td bgcolor=\"" + COULEUR_MARINE + "\">";
    html += "<span style=\"color:" + COULEUR_DORE + "; font-size:18pt; font-weight:bold;\">"
            "SMART WEATHER MANAGEMENT</span><br/>";
    html += "<span style=\"color:#FFFFFF; font-size:11pt;\">" + sousTitre.toHtmlEscaped() + "</span>";
    html += "</td></tr></table>";
    return html;
}

} // namespace

/* =====================================================================
 *  Constructeurs
 * ===================================================================== */

Employe::Employe()
    : m_id(0), m_salaire(0.0), m_statut("Actif")
{
}

Employe::Employe(int id, const QString &nom, const QString &prenom, const QString &email,
                 const QString &telephone, const QString &poste, const QString &service,
                 double salaire, const QString &statut, const QString &photo)
    : m_id(id), m_nom(nom), m_prenom(prenom), m_email(email), m_telephone(telephone),
      m_poste(poste), m_service(service), m_salaire(salaire), m_statut(statut),
      m_photo(photo)
{
}

/* =====================================================================
 *  Getters / Setters
 * ===================================================================== */

int Employe::getId() const { return m_id; }
QString Employe::getNom() const { return m_nom; }
QString Employe::getPrenom() const { return m_prenom; }
QString Employe::getEmail() const { return m_email; }
QString Employe::getTelephone() const { return m_telephone; }
QString Employe::getPoste() const { return m_poste; }
QString Employe::getService() const { return m_service; }
double Employe::getSalaire() const { return m_salaire; }
QString Employe::getStatut() const { return m_statut; }
QString Employe::getPhoto() const { return m_photo; }
QString Employe::derniereErreur() const { return m_erreur; }

void Employe::setId(int id) { m_id = id; }
void Employe::setNom(const QString &nom) { m_nom = nom; }
void Employe::setPrenom(const QString &prenom) { m_prenom = prenom; }
void Employe::setEmail(const QString &email) { m_email = email; }
void Employe::setTelephone(const QString &telephone) { m_telephone = telephone; }
void Employe::setPoste(const QString &poste) { m_poste = poste; }
void Employe::setService(const QString &service) { m_service = service; }
void Employe::setSalaire(double salaire) { m_salaire = salaire; }
void Employe::setStatut(const QString &statut) { m_statut = statut; }
void Employe::setPhoto(const QString &photo) { m_photo = photo; }

/* =====================================================================
 *  Contrôles de validité
 * ===================================================================== */

QStringList Employe::statutsValides()
{
    return QStringList() << "Actif" << "En congé" << "Inactif";
}

bool Employe::nomValide(const QString &texte)
{
    const QString t = texte.trimmed();
    if (t.size() < 2 || t.size() > 50) {
        return false;
    }
    static const QRegularExpression re("^\\p{L}[\\p{L} '\\-]*$");
    return re.match(t).hasMatch();
}

bool Employe::emailValide(const QString &texte)
{
    const QString t = texte.trimmed();
    if (t.isEmpty() || t.size() > 100) {
        return false;
    }
    static const QRegularExpression re(
        "^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9\\-]+(\\.[A-Za-z0-9\\-]+)*\\.[A-Za-z]{2,}$");
    return re.match(t).hasMatch();
}

bool Employe::telephoneValide(const QString &texte)
{
    static const QRegularExpression re("^[0-9]{8}$");
    return re.match(texte.trimmed()).hasMatch();
}

bool Employe::salaireValide(double salaire)
{
    return salaire > 0.0 && salaire <= 1000000.0;
}

QString Employe::verifierChamps() const
{
    if (!nomValide(m_nom)) {
        return "Le nom est invalide (2 à 50 lettres).";
    }
    if (!nomValide(m_prenom)) {
        return "Le prénom est invalide (2 à 50 lettres).";
    }
    if (!emailValide(m_email)) {
        return "L'adresse e-mail est invalide.";
    }
    if (!telephoneValide(m_telephone)) {
        return "Le téléphone doit contenir exactement 8 chiffres.";
    }
    if (m_poste.trimmed().isEmpty()) {
        return "Le poste est obligatoire.";
    }
    if (m_service.trimmed().isEmpty()) {
        return "Le service est obligatoire.";
    }
    if (!salaireValide(m_salaire)) {
        return "Le salaire doit être strictement positif.";
    }
    if (!statutsValides().contains(m_statut)) {
        return "Le statut doit être Actif, En congé ou Inactif.";
    }
    return QString();
}

/* =====================================================================
 *  Outils base de données
 * ===================================================================== */

int Employe::prochainId()
{
    QSqlQuery q;
    if (q.exec("SELECT COALESCE(MAX(ID), 0) + 1 FROM EMPLOYES") && q.next()) {
        return q.value(0).toInt();
    }
    return 1;
}

bool Employe::emailExiste(const QString &email, int idExclu)
{
    QSqlQuery q;
    q.prepare("SELECT COUNT(*) FROM EMPLOYES WHERE LOWER(EMAIL) = :email AND ID <> :id");
    q.bindValue(":email", email.trimmed().toLower());
    q.bindValue(":id", idExclu);
    if (q.exec() && q.next()) {
        return q.value(0).toInt() > 0;
    }
    return false;
}

Employe Employe::charger(int id, bool *ok)
{
    Employe e;
    if (ok) {
        *ok = false;
    }
    QSqlQuery q;
    q.prepare("SELECT ID, NOM, PRENOM, EMAIL, TELEPHONE, POSTE, SERVICE, SALAIRE, STATUT, PHOTO "
              "FROM EMPLOYES WHERE ID = :id");
    q.bindValue(":id", id);
    if (q.exec() && q.next()) {
        e.m_id = q.value(0).toInt();
        e.m_nom = q.value(1).toString();
        e.m_prenom = q.value(2).toString();
        e.m_email = q.value(3).toString();
        e.m_telephone = q.value(4).toString();
        e.m_poste = q.value(5).toString();
        e.m_service = q.value(6).toString();
        e.m_salaire = q.value(7).toDouble();
        e.m_statut = q.value(8).toString();
        e.m_photo = q.value(9).toString();
        if (ok) {
            *ok = true;
        }
    }
    return e;
}

/* =====================================================================
 *  CRUD
 * ===================================================================== */

bool Employe::ajouter()
{
    m_erreur.clear();

    const QString probleme = verifierChamps();
    if (!probleme.isEmpty()) {
        m_erreur = probleme;
        return false;
    }

    if (emailExiste(m_email, 0)) {
        m_erreur = "Cet e-mail est déjà utilisé par un autre employé.";
        return false;
    }

    const int nouvelId = prochainId();

    QSqlQuery q;
    q.prepare("INSERT INTO EMPLOYES (ID, NOM, PRENOM, EMAIL, TELEPHONE, POSTE, SERVICE, "
              "SALAIRE, STATUT, PHOTO) "
              "VALUES (:id, :nom, :prenom, :email, :telephone, :poste, :service, "
              ":salaire, :statut, :photo)");
    q.bindValue(":id", nouvelId);
    q.bindValue(":nom", m_nom.trimmed());
    q.bindValue(":prenom", m_prenom.trimmed());
    q.bindValue(":email", m_email.trimmed());
    q.bindValue(":telephone", m_telephone.trimmed());
    q.bindValue(":poste", m_poste.trimmed());
    q.bindValue(":service", m_service.trimmed());
    q.bindValue(":salaire", m_salaire);
    q.bindValue(":statut", m_statut);
    q.bindValue(":photo", m_photo);

    if (!q.exec()) {
        m_erreur = q.lastError().text();
        return false;
    }

    m_id = nouvelId;
    journaliser("AJOUT",
                QString("Ajout de l'employé %1 %2 (service : %3, poste : %4)")
                    .arg(m_prenom.trimmed(), m_nom.trimmed(), m_service.trimmed(), m_poste.trimmed()),
                m_id);
    return true;
}

QSqlQueryModel *Employe::afficher()
{
    return requete(QString(), "ID", "Croissant", QString(), QString());
}

bool Employe::modifier(int id)
{
    m_erreur.clear();

    bool existe = false;
    const Employe ancien = charger(id, &existe);
    if (!existe) {
        m_erreur = "Employé introuvable (ID " + QString::number(id) + ").";
        return false;
    }

    const QString probleme = verifierChamps();
    if (!probleme.isEmpty()) {
        m_erreur = probleme;
        return false;
    }

    if (emailExiste(m_email, id)) {
        m_erreur = "Cet e-mail est déjà utilisé par un autre employé.";
        return false;
    }

    QSqlQuery q;
    q.prepare("UPDATE EMPLOYES SET NOM = :nom, PRENOM = :prenom, EMAIL = :email, "
              "TELEPHONE = :telephone, POSTE = :poste, SERVICE = :service, "
              "SALAIRE = :salaire, STATUT = :statut, PHOTO = :photo "
              "WHERE ID = :id");
    q.bindValue(":nom", m_nom.trimmed());
    q.bindValue(":prenom", m_prenom.trimmed());
    q.bindValue(":email", m_email.trimmed());
    q.bindValue(":telephone", m_telephone.trimmed());
    q.bindValue(":poste", m_poste.trimmed());
    q.bindValue(":service", m_service.trimmed());
    q.bindValue(":salaire", m_salaire);
    q.bindValue(":statut", m_statut);
    q.bindValue(":photo", m_photo);
    q.bindValue(":id", id);

    if (!q.exec()) {
        m_erreur = q.lastError().text();
        return false;
    }

    QStringList changements;
    const auto comparer = [&changements](const QString &libelle, const QString &avant,
                                         const QString &apres) {
        if (avant != apres) {
            changements << QString("%1 : %2 -> %3").arg(libelle, avant, apres);
        }
    };
    comparer("nom", ancien.m_nom, m_nom.trimmed());
    comparer("prénom", ancien.m_prenom, m_prenom.trimmed());
    comparer("e-mail", ancien.m_email, m_email.trimmed());
    comparer("téléphone", ancien.m_telephone, m_telephone.trimmed());
    comparer("poste", ancien.m_poste, m_poste.trimmed());
    comparer("service", ancien.m_service, m_service.trimmed());
    comparer("salaire", formaterSalaire(ancien.m_salaire), formaterSalaire(m_salaire));
    comparer("statut", ancien.m_statut, m_statut);
    if (ancien.m_photo != m_photo) {
        changements << QString("photo de profil modifiée");
    }

    const QString details = changements.isEmpty()
                                ? QString("Mise à jour de l'employé %1 %2 (aucun changement détecté)")
                                      .arg(m_prenom.trimmed(), m_nom.trimmed())
                                : QString("Modification de %1 %2 - %3")
                                      .arg(m_prenom.trimmed(), m_nom.trimmed(),
                                           changements.join(" ; "));
    journaliser("MODIFICATION", details, id);

    m_id = id;
    return true;
}

bool Employe::supprimer(int id)
{
    m_erreur.clear();

    bool existe = false;
    const Employe courant = charger(id, &existe);
    if (!existe) {
        m_erreur = "Employé introuvable (ID " + QString::number(id) + ").";
        return false;
    }
    if (courant.m_statut == "Inactif") {
        m_erreur = "Cet employé est déjà inactif.";
        return false;
    }

    QSqlQuery q;
    q.prepare("UPDATE EMPLOYES SET STATUT = :statut WHERE ID = :id");
    q.bindValue(":statut", "Inactif");
    q.bindValue(":id", id);
    if (!q.exec()) {
        m_erreur = q.lastError().text();
        return false;
    }

    journaliser("DESACTIVATION",
                QString("Désactivation de l'employé %1 %2 (ancien statut : %3)")
                    .arg(courant.m_prenom, courant.m_nom, courant.m_statut),
                id);
    return true;
}

/* =====================================================================
 *  Tri et recherche
 * ===================================================================== */

QString Employe::colonneTri(const QString &critere)
{
    const QString c = critere.trimmed().toLower();
    if (c == "nom") {
        return "NOM";
    }
    if (c == "prénom" || c == "prenom") {
        return "PRENOM";
    }
    if (c == "e-mail" || c == "email") {
        return "EMAIL";
    }
    if (c == "salaire") {
        return "SALAIRE";
    }
    if (c == "service") {
        return "SERVICE";
    }
    if (c == "poste") {
        return "POSTE";
    }
    if (c == "statut") {
        return "STATUT";
    }
    return "ID";
}

QSqlQueryModel *Employe::requete(const QString &chaine, const QString &critere,
                                 const QString &ordre, const QString &service,
                                 const QString &statut)
{
    QString sql = "SELECT ID, NOM, PRENOM, EMAIL, TELEPHONE, POSTE, SERVICE, SALAIRE, STATUT "
                  "FROM EMPLOYES";

    QStringList conditions;

    const QString texte = chaine.trimmed().toLower();
    bool numerique = false;
    const int idRecherche = texte.toInt(&numerique);
    if (!texte.isEmpty()) {
        QString c = "(LOWER(NOM) LIKE :t1 OR LOWER(PRENOM) LIKE :t2 OR LOWER(EMAIL) LIKE :t3 "
                    "OR LOWER(POSTE) LIKE :t4 OR LOWER(SERVICE) LIKE :t5";
        if (numerique) {
            c += " OR ID = :idr";
        }
        c += ")";
        conditions << c;
    }

    const bool filtreService = !service.trimmed().isEmpty()
                               && !service.startsWith("Tous", Qt::CaseInsensitive);
    const bool filtreStatut = !statut.trimmed().isEmpty()
                              && !statut.startsWith("Tous", Qt::CaseInsensitive);
    if (filtreService) {
        conditions << "SERVICE = :svc";
    }
    if (filtreStatut) {
        conditions << "STATUT = :sta";
    }

    if (!conditions.isEmpty()) {
        sql += " WHERE " + conditions.join(" AND ");
    }

    const QString colonne = colonneTri(critere);
    const QString sens = ordre.trimmed().toLower().startsWith("d") ? "DESC" : "ASC";
    sql += " ORDER BY " + colonne + " " + sens;
    if (colonne != "ID") {
        sql += ", ID ASC";
    }

    QSqlQuery q;
    q.prepare(sql);
    if (!texte.isEmpty()) {
        const QString motif = "%" + texte + "%";
        q.bindValue(":t1", motif);
        q.bindValue(":t2", motif);
        q.bindValue(":t3", motif);
        q.bindValue(":t4", motif);
        q.bindValue(":t5", motif);
        if (numerique) {
            q.bindValue(":idr", idRecherche);
        }
    }
    if (filtreService) {
        q.bindValue(":svc", service.trimmed());
    }
    if (filtreStatut) {
        q.bindValue(":sta", statut.trimmed());
    }
    q.exec();

    QSqlQueryModel *modele = new QSqlQueryModel;
    modele->setQuery(std::move(q));
    modele->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    modele->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom"));
    modele->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
    modele->setHeaderData(3, Qt::Horizontal, QObject::tr("E-mail"));
    modele->setHeaderData(4, Qt::Horizontal, QObject::tr("Téléphone"));
    modele->setHeaderData(5, Qt::Horizontal, QObject::tr("Poste"));
    modele->setHeaderData(6, Qt::Horizontal, QObject::tr("Service"));
    modele->setHeaderData(7, Qt::Horizontal, QObject::tr("Salaire (DT)"));
    modele->setHeaderData(8, Qt::Horizontal, QObject::tr("Statut"));
    return modele;
}

QSqlQueryModel *Employe::trier(const QString &critere, const QString &ordre,
                               const QString &service, const QString &statut)
{
    return requete(QString(), critere, ordre, service, statut);
}

QSqlQueryModel *Employe::rechercher(const QString &chaine, const QString &critere,
                                    const QString &ordre, const QString &service,
                                    const QString &statut)
{
    return requete(chaine, critere, ordre, service, statut);
}

/* =====================================================================
 *  Exportation PDF
 * ===================================================================== */

bool Employe::exporterPDF(const QString &filename, QSqlQueryModel *modele,
                          const QString &description)
{
    m_erreur.clear();

    std::unique_ptr<QSqlQueryModel> modeleLocal;
    if (!modele) {
        modeleLocal.reset(afficher());
        modele = modeleLocal.get();
    }
    while (modele->canFetchMore()) {
        modele->fetchMore();
    }

    const int lignes = modele->rowCount();
    int actifs = 0;
    int enConge = 0;
    int inactifs = 0;
    for (int r = 0; r < lignes; ++r) {
        const QString statut = modele->data(modele->index(r, 8)).toString();
        if (statut == "Actif") {
            ++actifs;
        } else if (statut == "En congé") {
            ++enConge;
        } else if (statut == "Inactif") {
            ++inactifs;
        }
    }

    QString html = "<html><body style=\"font-family:Arial;\">";
    html += bandeauHtml("Rapport - Liste des employés");
    html += "<p style=\"font-size:9pt; color:" + COULEUR_MARINE + ";\">";
    html += "Édité le " + QDateTime::currentDateTime().toString("dd/MM/yyyy à HH:mm");
    html += " - <b>" + QString::number(lignes) + "</b> employé(s)";
    html += " (Actifs : " + QString::number(actifs) + ", En congé : " + QString::number(enConge)
            + ", Inactifs : " + QString::number(inactifs) + ")";
    if (!description.trimmed().isEmpty()) {
        html += "<br/>Critères : " + description.toHtmlEscaped();
    }
    html += "</p>";

    html += "<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"4\" "
            "style=\"border-color:" + COULEUR_MARINE + "; font-size:8pt;\">";
    html += "<tr bgcolor=\"" + COULEUR_MARINE + "\" style=\"color:#FFFFFF; font-weight:bold;\">";
    for (int c = 0; c < 9; ++c) {
        html += "<th align=\"left\" bgcolor=\"" + COULEUR_MARINE + "\"><span style=\"color:#FFFFFF;\">"
                + modele->headerData(c, Qt::Horizontal).toString().toHtmlEscaped()
                + "</span></th>";
    }
    html += "</tr>";

    for (int r = 0; r < lignes; ++r) {
        const QString fond = (r % 2 == 0) ? QString("#FFFFFF") : COULEUR_GRIS;
        html += "<tr bgcolor=\"" + fond + "\">";
        for (int c = 0; c < 9; ++c) {
            QString valeur = modele->data(modele->index(r, c)).toString();
            if (c == 7) {
                valeur = QString::number(valeur.toDouble(), 'f', 2);
            }
            html += "<td bgcolor=\"" + fond + "\">" + valeur.toHtmlEscaped() + "</td>";
        }
        html += "</tr>";
    }
    html += "</table>";

    if (lignes == 0) {
        html += "<p>Aucun employé ne correspond aux critères.</p>";
    }
    html += "</body></html>";

    QTextDocument document;
    document.setHtml(html);

    if (!ecrirePdf(filename, document)) {
        m_erreur = "Impossible d'écrire le fichier PDF : " + filename;
        return false;
    }

    journaliser("EXPORT_PDF",
                QString("Export PDF de la liste (%1 employé(s)) : %2")
                    .arg(lignes)
                    .arg(QFileInfo(filename).fileName()),
                0);
    return true;
}

bool Employe::exporterFichePDF(const QString &filename, int id)
{
    m_erreur.clear();

    bool existe = false;
    const Employe e = charger(id, &existe);
    if (!existe) {
        m_erreur = "Employé introuvable (ID " + QString::number(id) + ").";
        return false;
    }

    QTextDocument document;

    QString blocPhoto = "<i>Aucune photo</i>";
    if (!e.m_photo.isEmpty() && QFileInfo::exists(e.m_photo)) {
        QImage image(e.m_photo);
        if (!image.isNull()) {
            image = image.scaled(240, 240, Qt::KeepAspectRatio, Qt::SmoothTransformation);
            document.addResource(QTextDocument::ImageResource, QUrl("photo_employe"),
                                 QVariant(image));
            blocPhoto = "<img src=\"photo_employe\" width=\"" + QString::number(image.width() / 2)
                        + "\" height=\"" + QString::number(image.height() / 2) + "\" />";
        }
    }

    const auto ligne = [](const QString &libelle, const QString &valeur) {
        return "<tr><td width=\"32%\" bgcolor=\"" + COULEUR_GRIS + "\"><b>"
               + libelle.toHtmlEscaped() + "</b></td><td>" + valeur.toHtmlEscaped()
               + "</td></tr>";
    };

    QString html = "<html><body style=\"font-family:Arial; font-size:11pt;\">";
    html += bandeauHtml("Fiche détaillée de l'employé");
    html += "<h2 style=\"color:" + COULEUR_TURQUOISE + ";\">Employé n° " + QString::number(e.m_id)
            + " - " + (e.m_prenom + " " + e.m_nom).toHtmlEscaped() + "</h2>";
    html += "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"6\"><tr>";
    html += "<td width=\"28%\" align=\"center\" valign=\"top\">" + blocPhoto + "</td>";
    html += "<td width=\"72%\" valign=\"top\">";
    html += "<table width=\"100%\" border=\"1\" cellspacing=\"0\" cellpadding=\"6\" "
            "style=\"border-color:" + COULEUR_MARINE + ";\">";
    html += ligne("ID", QString::number(e.m_id));
    html += ligne("Nom", e.m_nom);
    html += ligne("Prénom", e.m_prenom);
    html += ligne("E-mail", e.m_email);
    html += ligne("Téléphone", e.m_telephone);
    html += ligne("Poste", e.m_poste);
    html += ligne("Service", e.m_service);
    html += ligne("Salaire", formaterSalaire(e.m_salaire));
    html += ligne("Statut", e.m_statut);
    html += "</table></td></tr></table>";
    html += "<p style=\"font-size:9pt; color:" + COULEUR_MARINE + ";\">Document édité le "
            + QDateTime::currentDateTime().toString("dd/MM/yyyy à HH:mm") + "</p>";
    html += "</body></html>";

    document.setHtml(html);

    if (!ecrirePdf(filename, document)) {
        m_erreur = "Impossible d'écrire le fichier PDF : " + filename;
        return false;
    }

    journaliser("EXPORT_PDF",
                QString("Export PDF de la fiche de %1 %2 : %3")
                    .arg(e.m_prenom, e.m_nom, QFileInfo(filename).fileName()),
                id);
    return true;
}

/* =====================================================================
 *  Statistiques graphiques (diagramme en barres dessiné dans un QGraphicsView)
 * ===================================================================== */

QString Employe::colonneStatistique(const QString &critere)
{
    const QString c = critere.trimmed().toLower();
    if (c == "poste") {
        return "POSTE";
    }
    if (c == "statut") {
        return "STATUT";
    }
    return "SERVICE";
}

int Employe::statistique(QGraphicsView *vue, const QString &critere)
{
    if (!vue) {
        return 0;
    }

    const QString colonne = colonneStatistique(critere);
    QString libelle = "service";
    if (colonne == "POSTE") {
        libelle = "poste";
    } else if (colonne == "STATUT") {
        libelle = "statut";
    }

    QVector<QPair<QString, int> > donnees;
    int total = 0;
    int maximum = 0;

    QSqlQuery q;
    if (q.exec("SELECT " + colonne + ", COUNT(*) FROM EMPLOYES GROUP BY " + colonne
               + " ORDER BY COUNT(*) DESC, " + colonne)) {
        while (q.next()) {
            const QString nom = q.value(0).toString();
            const int nombre = q.value(1).toInt();
            donnees.append(qMakePair(nom, nombre));
            total += nombre;
            if (nombre > maximum) {
                maximum = nombre;
            }
        }
    }

    const QVector<QColor> palette = {QColor("#208A9A"), QColor("#E6A15C"), QColor("#24384B"),
                                     QColor("#5FB3C0"), QColor("#C9873F"), QColor("#4A6A85")};

    const int nb = donnees.size();
    const qreal largeurBarre = 70;
    const qreal espace = 40;
    const qreal margeGauche = 60;
    const qreal margeHaut = 70;
    const qreal hauteurGraphique = 260;
    const qreal margeBas = 90;

    qreal largeurScene = margeGauche + nb * (largeurBarre + espace) + 30;
    if (largeurScene < 640) {
        largeurScene = 640;
    }
    const qreal hauteurScene = margeHaut + hauteurGraphique + margeBas;

    QGraphicsScene *scene = new QGraphicsScene(vue);
    scene->setSceneRect(0, 0, largeurScene, hauteurScene);
    scene->setBackgroundBrush(QBrush(QColor("#FFFFFF")));

    QGraphicsTextItem *titre = scene->addText(
        "Répartition des employés par " + libelle + " (total : " + QString::number(total) + ")",
        QFont("Arial", 13, QFont::Bold));
    titre->setDefaultTextColor(QColor("#24384B"));
    titre->setPos(margeGauche, 15);

    if (nb == 0) {
        QGraphicsTextItem *vide = scene->addText("Aucune donnée à afficher.", QFont("Arial", 12));
        vide->setDefaultTextColor(QColor("#24384B"));
        vide->setPos(margeGauche, margeHaut + 40);
    } else {
        int pas = 1;
        if (maximum > 5) {
            pas = static_cast<int>(std::ceil(maximum / 5.0));
        }
        int axeMax = static_cast<int>(std::ceil(maximum / static_cast<double>(pas))) * pas;
        if (axeMax < 1) {
            axeMax = 1;
        }

        const qreal yBase = margeHaut + hauteurGraphique;

        for (int v = 0; v <= axeMax; v += pas) {
            const qreal y = yBase - hauteurGraphique * v / axeMax;
            scene->addLine(margeGauche, y, largeurScene - 20, y, QPen(QColor("#D5DEE5"), 1));
            QGraphicsTextItem *graduation = scene->addText(QString::number(v), QFont("Arial", 9));
            graduation->setDefaultTextColor(QColor("#24384B"));
            graduation->setPos(margeGauche - 36, y - 11);
        }

        scene->addLine(margeGauche, margeHaut, margeGauche, yBase, QPen(QColor("#24384B"), 2));
        scene->addLine(margeGauche, yBase, largeurScene - 20, yBase, QPen(QColor("#24384B"), 2));

        for (int i = 0; i < nb; ++i) {
            const QString nomCategorie = donnees.at(i).first.isEmpty()
                                             ? QString("(non renseigné)")
                                             : donnees.at(i).first;
            const int nombre = donnees.at(i).second;
            const qreal x = margeGauche + espace / 2 + i * (largeurBarre + espace);
            const qreal hauteur = hauteurGraphique * nombre / axeMax;
            const qreal y = yBase - hauteur;

            scene->addRect(x, y, largeurBarre, hauteur, QPen(Qt::NoPen),
                           QBrush(palette.at(i % palette.size())));

            const double pourcentage = total > 0 ? 100.0 * nombre / total : 0.0;
            QGraphicsTextItem *valeur = scene->addText(
                QString::number(nombre) + " (" + QString::number(pourcentage, 'f', 0) + " %)",
                QFont("Arial", 9, QFont::Bold));
            valeur->setDefaultTextColor(QColor("#24384B"));
            valeur->setPos(x + largeurBarre / 2 - valeur->boundingRect().width() / 2, y - 24);

            QGraphicsTextItem *etiquette = scene->addText(nomCategorie, QFont("Arial", 9));
            etiquette->setDefaultTextColor(QColor("#24384B"));
            etiquette->setTextWidth(largeurBarre + espace - 6);
            QTextOption option;
            option.setAlignment(Qt::AlignHCenter);
            etiquette->document()->setDefaultTextOption(option);
            etiquette->setPos(x - espace / 2 + 3, yBase + 6);
        }
    }

    QGraphicsScene *ancienne = vue->scene();
    vue->setScene(scene);
    delete ancienne;

    vue->setRenderHint(QPainter::Antialiasing);
    vue->fitInView(scene->sceneRect(), Qt::KeepAspectRatio);
    return total;
}

/* =====================================================================
 *  Métier innovant A : historique d'activité (table LOGS)
 * ===================================================================== */

void Employe::journaliser(const QString &action, const QString &details, int idEmploye)
{
    int nouvelId = 1;
    {
        QSqlQuery qId;
        if (qId.exec("SELECT COALESCE(MAX(ID), 0) + 1 FROM LOGS") && qId.next()) {
            nouvelId = qId.value(0).toInt();
        }
    }

    QSqlQuery q;
    q.prepare("INSERT INTO LOGS (ID, DATE_LOG, ACTION_LOG, DETAILS, EMPLOYE_ID) "
              "VALUES (:id, :date, :action, :details, :employe)");
    q.bindValue(":id", nouvelId);
    q.bindValue(":date", QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"));
    q.bindValue(":action", action.left(30));
    q.bindValue(":details", details.left(250));
    q.bindValue(":employe", idEmploye);
    q.exec();
}

QSqlQueryModel *Employe::historique(int idEmploye)
{
    QString sql = "SELECT DATE_LOG, ACTION_LOG, EMPLOYE_ID, DETAILS FROM LOGS";
    if (idEmploye > 0) {
        sql += " WHERE EMPLOYE_ID = :id";
    }
    sql += " ORDER BY ID DESC";

    QSqlQuery q;
    q.prepare(sql);
    if (idEmploye > 0) {
        q.bindValue(":id", idEmploye);
    }
    q.exec();

    QSqlQueryModel *modele = new QSqlQueryModel;
    modele->setQuery(std::move(q));
    modele->setHeaderData(0, Qt::Horizontal, QObject::tr("Date / Heure"));
    modele->setHeaderData(1, Qt::Horizontal, QObject::tr("Action"));
    modele->setHeaderData(2, Qt::Horizontal, QObject::tr("ID employé"));
    modele->setHeaderData(3, Qt::Horizontal, QObject::tr("Description"));
    return modele;
}
