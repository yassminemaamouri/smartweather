#include <QApplication>
#include <QMessageBox>

#include "connection.h"
#include "gestionemployes.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    /* Nécessaire pour que le dossier de données (base SQLite, photos) soit bien nommé. */
    QCoreApplication::setOrganizationName("SWM");
    QCoreApplication::setApplicationName("SmartWeatherManagement");

    Connection connexion;
    if (!connexion.createConnection()) {
        QMessageBox::critical(nullptr, "Connexion à la base de données",
                              "Impossible d'ouvrir la base de données.\n\n"
                                  + connexion.messageErreur());
        return 1;
    }

    GestionEmployes fenetre;
    fenetre.setWindowTitle("Smart Weather Management - Gestion des employés  [base : "
                           + connexion.description() + "]");
    fenetre.show();

    return a.exec();
}
