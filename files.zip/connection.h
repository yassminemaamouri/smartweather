#ifndef CONNECTION_H
#define CONNECTION_H

#include <QCoreApplication>
#include <QDir>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QStandardPaths>
#include <QString>
#include <QStringList>

/*
 * Mettre 1 pour tenter d'abord Oracle (via ODBC), puis se replier sur SQLite
 * si Oracle est indisponible. Mettre 0 pour utiliser uniquement SQLite.
 */
#define SWM_ESSAYER_ORACLE 1

class Connection
{
public:
    Connection() : m_oracle(false) {}

    /* Ouvre la connexion par défaut et crée les tables EMPLOYES et LOGS si besoin. */
    bool createConnection()
    {
        m_erreur.clear();
        m_oracle = false;

        bool ouverte = false;

#if SWM_ESSAYER_ORACLE
        if (QSqlDatabase::isDriverAvailable("QODBC")) {
            ouverte = ouvrirOracle();
            if (ouverte) {
                m_oracle = true;
            }
        } else {
            m_erreur = "Pilote QODBC indisponible. ";
        }
#endif

        if (!ouverte) {
            ouverte = ouvrirSqlite();
        }

        if (!ouverte) {
            return false;
        }

        return creerTables();
    }

    bool estOracle() const { return m_oracle; }

    QString messageErreur() const { return m_erreur; }

    QString description() const
    {
        return m_oracle ? QString("Oracle (ODBC)") : QString("SQLite (fichier local)");
    }

    /* Dossier d'écriture de l'application (base SQLite, photos de profil). */
    static QString dossierDonnees()
    {
        QString dossier = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
        if (dossier.isEmpty()) {
            dossier = QCoreApplication::applicationDirPath();
        }
        QDir().mkpath(dossier);
        return dossier;
    }

private:
    bool ouvrirOracle()
    {
        /* À adapter : nom de la source ODBC, utilisateur et mot de passe Oracle. */
        const QString sourceOdbc = "Source_Projet2A";
        const QString utilisateur = "projet2a";
        const QString motDePasse = "mp2a";

        bool ok = false;
        {
            QSqlDatabase db = QSqlDatabase::addDatabase("QODBC");
            db.setDatabaseName(sourceOdbc);
            db.setUserName(utilisateur);
            db.setPassword(motDePasse);
            db.setConnectOptions("SQL_ATTR_LOGIN_TIMEOUT=3");
            ok = db.open();
            if (!ok) {
                m_erreur += "Oracle : " + db.lastError().text() + " ";
            }
        }
        if (!ok) {
            QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
        }
        return ok;
    }

    bool ouvrirSqlite()
    {
        bool ok = false;
        {
            QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
            db.setDatabaseName(dossierDonnees() + "/smartweather.db");
            ok = db.open();
            if (!ok) {
                m_erreur += "SQLite : " + db.lastError().text();
            }
        }
        if (!ok) {
            QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
        }
        return ok;
    }

    bool tableExiste(const QString &nom) const
    {
        const QStringList tables = QSqlDatabase::database().tables(QSql::Tables);
        for (const QString &t : tables) {
            if (t.compare(nom, Qt::CaseInsensitive) == 0) {
                return true;
            }
        }
        return false;
    }

    bool creerTables()
    {
        if (!tableExiste("EMPLOYES")) {
            QSqlQuery q;
            const bool ok = q.exec(
                "CREATE TABLE EMPLOYES ("
                "ID INTEGER PRIMARY KEY, "
                "NOM VARCHAR(50) NOT NULL, "
                "PRENOM VARCHAR(50) NOT NULL, "
                "EMAIL VARCHAR(100) NOT NULL UNIQUE, "
                "TELEPHONE VARCHAR(8) NOT NULL, "
                "POSTE VARCHAR(50) NOT NULL, "
                "SERVICE VARCHAR(60) NOT NULL, "
                "SALAIRE FLOAT NOT NULL CHECK (SALAIRE > 0), "
                "STATUT VARCHAR(20) DEFAULT 'Actif' NOT NULL, "
                "PHOTO VARCHAR(255))");
            if (!ok) {
                m_erreur = "Création de la table EMPLOYES : " + q.lastError().text();
                return false;
            }
        }

        if (!tableExiste("LOGS")) {
            QSqlQuery q;
            const bool ok = q.exec(
                "CREATE TABLE LOGS ("
                "ID INTEGER PRIMARY KEY, "
                "DATE_LOG VARCHAR(25) NOT NULL, "
                "ACTION_LOG VARCHAR(30) NOT NULL, "
                "DETAILS VARCHAR(255), "
                "EMPLOYE_ID INTEGER DEFAULT 0)");
            if (!ok) {
                m_erreur = "Création de la table LOGS : " + q.lastError().text();
                return false;
            }
        }
        return true;
    }

    bool m_oracle;
    QString m_erreur;
};

#endif // CONNECTION_H
