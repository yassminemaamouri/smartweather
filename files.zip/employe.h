#ifndef EMPLOYE_H
#define EMPLOYE_H

#include <QSqlQueryModel>
#include <QString>
#include <QStringList>

class QGraphicsView;

class Employe
{
public:
    /* ---------- Constructeurs ---------- */
    Employe();
    Employe(int id, const QString &nom, const QString &prenom, const QString &email,
            const QString &telephone, const QString &poste, const QString &service,
            double salaire, const QString &statut, const QString &photo = QString());

    /* ---------- Getters ---------- */
    int getId() const;
    QString getNom() const;
    QString getPrenom() const;
    QString getEmail() const;
    QString getTelephone() const;
    QString getPoste() const;
    QString getService() const;
    double getSalaire() const;
    QString getStatut() const;
    QString getPhoto() const;

    /* ---------- Setters ---------- */
    void setId(int id);
    void setNom(const QString &nom);
    void setPrenom(const QString &prenom);
    void setEmail(const QString &email);
    void setTelephone(const QString &telephone);
    void setPoste(const QString &poste);
    void setService(const QString &service);
    void setSalaire(double salaire);
    void setStatut(const QString &statut);
    void setPhoto(const QString &photo);

    /* ---------- CRUD ---------- */
    bool ajouter();
    QSqlQueryModel *afficher();
    bool modifier(int id);
    bool supprimer(int id); /* désactivation : statut = 'Inactif' */

    /* ---------- Métiers basiques ---------- */
    QSqlQueryModel *trier(const QString &critere, const QString &ordre,
                          const QString &service = QString(),
                          const QString &statut = QString());
    QSqlQueryModel *rechercher(const QString &chaine,
                               const QString &critere = QString("ID"),
                               const QString &ordre = QString("Croissant"),
                               const QString &service = QString(),
                               const QString &statut = QString());
    bool exporterPDF(const QString &filename, QSqlQueryModel *modele = nullptr,
                     const QString &description = QString());
    bool exporterFichePDF(const QString &filename, int id);
    int statistique(QGraphicsView *vue, const QString &critere = QString("SERVICE"));

    /* ---------- Outils ---------- */
    static Employe charger(int id, bool *ok = nullptr);
    static bool emailExiste(const QString &email, int idExclu = 0);
    static int prochainId();
    static QStringList statutsValides();

    static bool nomValide(const QString &texte);
    static bool emailValide(const QString &texte);
    static bool telephoneValide(const QString &texte);
    static bool salaireValide(double salaire);

    /* ---------- Métier innovant A : historique ---------- */
    static void journaliser(const QString &action, const QString &details, int idEmploye);
    static QSqlQueryModel *historique(int idEmploye = 0);

    QString derniereErreur() const;
    QString verifierChamps() const;

private:
    static QSqlQueryModel *requete(const QString &chaine, const QString &critere,
                                   const QString &ordre, const QString &service,
                                   const QString &statut);
    static QString colonneTri(const QString &critere);
    static QString colonneStatistique(const QString &critere);

    int m_id;
    QString m_nom;
    QString m_prenom;
    QString m_email;
    QString m_telephone;
    QString m_poste;
    QString m_service;
    double m_salaire;
    QString m_statut;
    QString m_photo;
    QString m_erreur;
};

#endif // EMPLOYE_H
