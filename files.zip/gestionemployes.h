#ifndef GESTIONEMPLOYES_H
#define GESTIONEMPLOYES_H

#include <QString>
#include <QWidget>

#include "employe.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class GestionEmployes;
}
QT_END_NAMESPACE

class QModelIndex;
class QResizeEvent;
class QSqlQueryModel;

class GestionEmployes : public QWidget
{
    Q_OBJECT

public:
    explicit GestionEmployes(QWidget *parent = nullptr);
    ~GestionEmployes() override;

protected:
    void resizeEvent(QResizeEvent *event) override;

private slots:
    /* CRUD */
    void slotAjouter();
    void slotModifier();
    void slotSupprimer();
    void slotAnnuler();

    /* Recherche instantanée, tri et filtres */
    void slotRechercher(const QString &texte);
    void slotTrier();

    /* Exportation PDF */
    void slotExporterPDF();
    void slotExporterFichePDF();

    /* Statistiques */
    void slotAfficherStatistiques();
    void slotActualiserStatistiques();
    void slotChangementOnglet(int index);

    /* Métiers innovants */
    void slotParcourirPhoto();
    void slotAfficherHistorique();

    /* Sélection dans le tableau */
    void slotLigneChangee(const QModelIndex &courant, const QModelIndex &precedent);

private:
    void appliquerCharteGraphique();
    void configurerChamps();
    void actualiserListe();
    void definirModele(QSqlQueryModel *nouveau);
    void remplirFiche(const Employe &employe);
    void viderFiche();
    void afficherPhoto(const QString &chemin);
    void avertir(const QString &message, QWidget *champ);
    bool lireEtValiderFiche(Employe &employe, bool &nouvellePhoto);
    QString enregistrerPhoto(const QString &source);
    static QString dossierPhotos();

    Ui::GestionEmployes *ui;
    QSqlQueryModel *m_modele;
    int m_idSelectionne;
    QString m_cheminPhoto;   /* photo enregistrée en base pour l'employé affiché */
    QString m_photoSource;   /* nouvelle image choisie, pas encore enregistrée */
};

#endif // GESTIONEMPLOYES_H
